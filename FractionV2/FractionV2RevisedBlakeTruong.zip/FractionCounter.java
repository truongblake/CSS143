package CS143.FractionV2;

import java.util.ArrayList;

public class FractionCounter {

    Fraction fraction;
    int counter;
    /**Description: return fraction as a string.
     * Pre-Condition:
     * Post-Condition: returns a well formatted fraction back as a String.
     * @author Blake Truong
     */
    public FractionCounter(Fraction theFraction){

        this.fraction = theFraction;
        this.counter = 1;

    }
    /**Description: return fraction as a string.
     * Pre-Condition:
     * Post-Condition: returns a well formatted fraction back as a String.
     * @author Blake Truong
     */
    public boolean compareAndIncrement(Fraction fraction){
        if(fraction.equals(this.fraction)){
            counter++;
            return true;
        }
        return false;
    }
    /**Description: return fraction as a string.
     * Pre-Condition:
     * Post-Condition: returns a well formatted fraction back as a String.
     * @author Blake Truong
     */
    public String toString(){
        return fraction.toString() + " has a count of " + counter;
    }

}
