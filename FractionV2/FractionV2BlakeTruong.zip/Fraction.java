package CS143.FractionV2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Fraction {

    private int numerator;
    private int denominator;

    public Fraction(int numerator, int denominator){

        if(denominator != 0) {
            this.numerator = numerator / gcd(numerator, denominator);
            this.denominator = denominator / gcd(numerator, denominator);
        }else{
            this.numerator = numerator;
            this.denominator = 1;
        }
    }

    public Fraction(){
        this(1,1);
    }

    public int getDenominator() {
        return denominator;
    }

    public int getNumerator() {
        return numerator;
    }

    public void setDenominator(int denominator) {
        if(denominator != 0) {
            this.denominator = denominator;
        }else{
            System.out.println("denominator cannot be 0");
        }
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator;
    }

    public boolean equals(Object other){
        Fraction object = (Fraction) other;
        if(object.numerator == this.numerator && object.denominator == this.denominator
                || -object.numerator == this.numerator && -object.denominator == this.denominator){
            return true;
        }else{
            return false;
        }
    }

    public String toString(){
        if(this.denominator < 0 && this.numerator > 0){
            return -this.numerator + "/" + -this.denominator;
        }
        else if(this.denominator > 0 && this.numerator < 0) {
            return this.numerator + "/" + this.denominator;
        }
        else{
            return this.numerator + "/" + this.denominator;
        }
    }
    /** gcd(int a, int b)
     * -------
     * Description: Gets the greatest common divisor of the two integers.
     * Pre-Condition: a and b must be integers
     * Post-Condition: returns the greatest common divisor as an int.
     * @author Blake Truong
     * @return int
     * @parameter a: a is an int, b: b is an int.
     */

    private int gcd(int a, int b){
        if(a > b){
            int temp = a;
            a = b;
            b = temp;
        }
        while(b%a != 0){
            a = b%a;
        }
        return a;
    }
}
