package CS143.FractionV2;

import java.util.ArrayList;

public class FractionCounter {

    Fraction fraction;
    int counter;

    public FractionCounter(Fraction theFraction){

        this.fraction = theFraction;
        this.counter = 1;

    }

    public boolean compareAndIncrement(Fraction fraction){
        if(fraction.equals(this.fraction)){
            counter++;
            return true;
        }
        return false;
    }

    public String toString(){
        return fraction.toString() + " has a count of " + counter;
    }

}
